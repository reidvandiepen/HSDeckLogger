//
//  AddGameViewController.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 1/16/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit

class AddGameViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        classPicker.delegate=self
        deckText.delegate=self
        oppClassPicker.delegate=self
        oppDeckText.delegate=self
        
        classPicker.dataSource=self
        oppClassPicker.dataSource=self
        
        
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
        textField.resignFirstResponder()
        return true
    }

    let classNames=["Druid", "Hunter", "Mage", "Paladin", "Priest", "Rogue", "Shaman", "Warlock", "Warrior"]
    
    @IBOutlet weak var deckText: UITextField!
    @IBOutlet weak var oppDeckText: UITextField!
    
    @IBOutlet weak var classPicker: UIPickerView!
    @IBOutlet weak var oppClassPicker: UIPickerView!
    
    @IBOutlet weak var wlSwitch: UISwitch!

    
    @IBAction func confirmPressed(_ sender: Any) {
        guard let strDeck=deckText.text, let strOppDeck=oppDeckText.text else {return}
    
        let strClass=classNames[classPicker.selectedRow(inComponent: 0)]
        let strOppClass=classNames[oppClassPicker.selectedRow(inComponent: 0)]
        
        PlayedGamesController.addGame(classStr: strClass, deck: strDeck, oppClass: strOppClass, oppDeck: strOppDeck, winIn: wlSwitch.isOn)
        
        classPicker.selectRow(0, inComponent: 0, animated: false)
        deckText.text=""
        oppDeckText.text=""
        oppClassPicker.selectRow(0, inComponent: 0, animated: false)
        wlSwitch.setOn(true, animated: true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return classNames.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return classNames[row]
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func saveTapped(_ sender: Any) {
        guard let strDeck=deckText.text, let strOppDeck=oppDeckText.text else {return}
        
        let strClass=classNames[classPicker.selectedRow(inComponent: 0)]
        let strOppClass=classNames[oppClassPicker.selectedRow(inComponent: 0)]
        
        PlayedGamesController.addGame(classStr: strClass, deck: strDeck, oppClass: strOppClass, oppDeck: strOppDeck, winIn: wlSwitch.isOn)
        
        classPicker.selectRow(0, inComponent: 0, animated: false)
        deckText.text=""
        oppDeckText.text=""
        oppClassPicker.selectRow(0, inComponent: 0, animated: false)
        wlSwitch.setOn(true, animated: true)
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancelTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
