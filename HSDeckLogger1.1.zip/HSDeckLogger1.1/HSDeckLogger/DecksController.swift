//
//  SecondViewController.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 1/7/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit

class DecksController: UITableViewController {
    
    
    class DeckCellData{
        let className:String
        let deckName:String
        var winrates:[Winrate]
        
        init(className: String, deckName: String, winrates: [Winrate]) {
            self.className=className
            self.deckName=deckName
            self.winrates=winrates
        }
    }
    
    class Winrate {
        let oppClassName:String
        let oppDeckName:String
        var wins:[Int] //append 0 for a loss, 1 for a win to this array
        
        init(oppClassName: String, oppDeckName: String, wins: [Int]) {
            self.oppClassName=oppClassName
            self.oppDeckName=oppDeckName
            self.wins=wins
        }
    }
    
    var allDecks:[DeckCellData]=[]
    
    let classNames=["Druid", "Hunter", "Mage", "Paladin", "Priest", "Rogue", "Shaman", "Warlock", "Warrior"]
    
    func createDecks() {
        guard let games=PlayedGamesController.games else {return}
        
        allDecks=[]
        
        for game in games {
            if let deck=checkDeckExists(game: game) {
                checkOppDeckExists(game: game, deck: deck)
            }
        }
    }
    
    
    func checkDeckExists(game: PlayedGamesController.Game) -> DeckCellData? {
        var exists=false
        var counter=0
        var location=0
        for deck in allDecks {
            if game.className==deck.className && game.deckName==deck.deckName {
                exists=true
                location=counter
            }
            counter+=1
        }
        
        if exists {
            return allDecks[location]
        } else if game.win{
            allDecks.append(DeckCellData(className: game.className, deckName: game.deckName, winrates: [Winrate(oppClassName: game.oppClassName, oppDeckName: game.oppDeckName, wins: [1])]))
            return nil
        } else {
            allDecks.append(DeckCellData(className: game.className, deckName: game.deckName, winrates: [Winrate(oppClassName: game.oppClassName, oppDeckName: game.oppDeckName, wins: [0])]))
            return nil
            
        }
    }
    
    func checkOppDeckExists(game: PlayedGamesController.Game, deck: DeckCellData) -> Bool {
        var exists=false
        for winrate in deck.winrates {
            if winrate.oppClassName==game.oppClassName && winrate.oppDeckName==game.oppDeckName {
                exists=true
                if game.win {
                    winrate.wins.append(1)
                } else {
                    winrate.wins.append(0)
                }
            }
        }
        if exists {
            return true
        } else {
            if game.win {
                deck.winrates.append(Winrate(oppClassName: game.oppClassName, oppDeckName: game.oppDeckName, wins: [1]))
            } else {
                deck.winrates.append(Winrate(oppClassName: game.oppClassName, oppDeckName: game.oppDeckName, wins: [0]))
            }
            return false
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allDecks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "deckCell") as! DeckTableViewCell
        
        cell.selectionStyle = .default
        
        cell.updateWith(deck: allDecks[indexPath.row])
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 200.0

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        allDecks=[]
        
        createDecks()
        
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "deckStatistics", sender: indexPath)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "deckStatistics" {
            let indexPath = tableView.indexPathForSelectedRow!
            let deck = allDecks[indexPath.row]
            let navController = segue.destination as! UINavigationController
            let statisticsTableViewController = navController.topViewController as!StatisticsTableViewController
            
            statisticsTableViewController.navController=navController
            statisticsTableViewController.deckInfo = deck
        }
    }
    
}

