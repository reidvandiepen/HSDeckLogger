//
//  FirstViewController.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 1/7/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit

class PlayedGamesController: UITableViewController {
    
    
    class Game: Codable {
        var className:String
        var deckName:String
        var oppClassName:String
        var oppDeckName:String
        var win:Bool=false
        
        init(className: String, deckName: String, oppClassName: String, oppDeckName: String, win: Bool) {
            self.className=className
            self.deckName=deckName
            self.oppClassName=oppClassName
            self.oppDeckName=oppDeckName
            self.win=win
        }
        
        static var archiveURL:URL {
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory,in: .userDomainMask).first!
            let archiveURL = documentsDirectory.appendingPathComponent("deck_logger").appendingPathExtension("plist")
            return archiveURL
        }
        
        static func saveToFile(games: [Game]) {
            let propertyListEncoder = PropertyListEncoder()
            let encodedGames = try? propertyListEncoder.encode(games)
            
            try? encodedGames?.write(to: archiveURL, options: .noFileProtection)
        }
        
        static func loadFromFile() -> [Game]? {
            let propertyListDecoder = PropertyListDecoder()
            if let retrievedGamesData = try? Data(contentsOf: archiveURL), let decodedGames = try?propertyListDecoder.decode(Array<Game>.self, from: retrievedGamesData)  {
                    return(decodedGames)
                }
            return nil
            }
        
    }
    
    static var games:[Game]?
    
    static func addGame(classStr:String, deck:String, oppClass:String, oppDeck:String, winIn:Bool)  {
        
        if games==nil {
            games=[Game(className: classStr, deckName: deck, oppClassName: oppClass, oppDeckName: oppDeck, win: winIn)]
        } else {
            games?.append(Game(className: classStr, deckName: deck, oppClassName: oppClass, oppDeckName: oppDeck, win: winIn))
        }
        
        Game.saveToFile(games: self.games!)
        
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        guard PlayedGamesController.games != nil else { return 0 }
        return PlayedGamesController.games!.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300 //fix later?
    }
    
    override func tableView(_ tableView: UITableView,
                               editingStyleForRowAt indexPath: IndexPath) ->
        UITableViewCell.EditingStyle {
            return .delete
    }
    
    override func tableView(_ tableView: UITableView, commit
        editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath:
        IndexPath) {
        if editingStyle == .delete {
            PlayedGamesController.games?.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: . automatic)
            Game.saveToFile(games: PlayedGamesController.games ?? [])
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "gameCell") as! GameTableViewCell
        
        guard PlayedGamesController.games != nil else {return cell}
        cell.updateWith(game: PlayedGamesController.games![indexPath.section])
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return (PlayedGamesController.games![section].deckName + " " + PlayedGamesController.games![section].className + " vs. " + PlayedGamesController.games![section].oppDeckName + " " + PlayedGamesController.games![section].oppClassName)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        PlayedGamesController.games = Game.loadFromFile()
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 300.0
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
}

