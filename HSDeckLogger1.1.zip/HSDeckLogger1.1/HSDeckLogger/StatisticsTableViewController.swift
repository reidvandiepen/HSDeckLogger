//
//  StatisticsTableViewController.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 2/19/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit

class StatisticsTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title=navTitle
        
    }
    
    var navController:UINavigationController?
    var deckInfo:DecksController.DeckCellData?
    var navTitle: String? {
        return deckInfo?.className
    }
    var existingOppClasses:[String] {
        guard deckInfo != nil else {return []}
        
        var originals:[String]=[]
        for winrate in deckInfo!.winrates {
            originals.append(winrate.oppClassName)
        }
        
        return Array(Set(originals))
    }
    
    func getClassWinrates(oppClass: String) -> [DecksController.Winrate] {
        var temp:[DecksController.Winrate]=[]
        guard deckInfo != nil else {return []}
        for winrate in deckInfo!.winrates {
            if winrate.oppClassName == oppClass {
                temp.append(winrate)
            }
        }
        return temp
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return existingOppClasses.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "statisticsCell", for: indexPath) as! StatisticsTableViewCell

        cell.selectionStyle = .none
        
        print(getClassWinrates(oppClass: existingOppClasses[indexPath.section]))
        
        cell.updateWith(winrates: getClassWinrates(oppClass: existingOppClasses[indexPath.section]), oppClass: existingOppClasses[indexPath.section])

        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return existingOppClasses[section]
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 330
    }


    // MARK: - Navigation
    @IBAction func backTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
