//
//  DeckTableViewCell.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 1/14/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit

class DeckTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    func updateWith(deck: DecksController.DeckCellData) {
        classLabel?.text="Class: "+deck.className
        deckLabel?.text="Deck: "+deck.deckName
        wrLabel?.text="Winrate: "+String(calcBasicWR(deck: deck))+"%"
    }
    
    func calcBasicWR(deck: DecksController.DeckCellData) -> Double {
        var totalGames=0.0
        var wonGames=0.0
        for winrate in deck.winrates {
            for wins in winrate.wins {
                totalGames+=1
                wonGames+=Double(wins)
            }
        }
        return ((wonGames/totalGames)*10_000).rounded()/100.0
    }
    
    
    
    
    @IBOutlet weak var classLabel: UILabel!
    @IBOutlet weak var deckLabel: UILabel!
    @IBOutlet weak var wrLabel: UILabel!
}
