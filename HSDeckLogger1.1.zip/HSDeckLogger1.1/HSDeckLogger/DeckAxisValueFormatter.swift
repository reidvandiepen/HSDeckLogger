//
//  DeckAxisValueFormatter.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 2/25/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit
import Charts

class DeckAxisValueFormatter: NSObject, IAxisValueFormatter {

    weak var chart: BarLineChartViewBase?
    var decks:[String]=[]
    
    init(chart: BarLineChartViewBase, decks: [String]) {
        self.chart = chart
        self.decks = decks
    }
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return decks[Int(value)]
    }
}
