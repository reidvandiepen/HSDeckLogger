//
//  GameTableViewCell.swift
//  HSDeckLogger
//
//  Created by Reid Vandiepen on 1/15/19.
//  Copyright © 2019 Reid Vandiepen. All rights reserved.
//

import UIKit

class GameTableViewCell: UITableViewCell, UIPickerViewDelegate {

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateWith(game: PlayedGamesController.Game) {
        classLabel?.text="Class: "+game.className
        deckLabel?.text="Deck: "+game.deckName
        oppDeckLabel?.text="Opp. Deck: "+game.oppDeckName
        oppClassLabel?.text="Opp. Class: "+game.oppClassName
        if game.win {
            wlLabel?.text="W/L: Win"
        } else {
            wlLabel?.text="W/L: Loss"
        }
    }
    
    
    @IBOutlet weak var classLabel: UILabel!
    @IBOutlet weak var deckLabel: UILabel!
    @IBOutlet weak var oppClassLabel: UILabel!
    @IBOutlet weak var oppDeckLabel: UILabel!
    @IBOutlet weak var wlLabel: UILabel!
    
    
}
